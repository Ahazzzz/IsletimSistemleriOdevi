/*
 * scheduler.c
 * -----------
 * Çok seviyeli kuyruk (MLFQ benzeri) yaklaşımıyla basit bir proses zamanlama simülasyonu.
 *
 * Genel akış:
 *  - Dosyadan prosesleri (arrivalTime, priority, burstTime) oku.
 *  - globalTime her saniye 1 artar (vTaskDelay ile 1000 ms beklenir).
 *  - arrivalTime == globalTime olan prosesler ilgili öncelik kuyruğuna eklenir.
 *  - En üst öncelikli dolu kuyruktan bir proses seçilir ve 1 sn çalıştırılır.
 *  - Öncelik seviyesi 0 hariç prosesler her quantum sonunda askıya alınıp bir alt
 *    kuyruğa (priority++) taşınır (demote).
 *  - 20 sn içinde başlamayan veya belirli koşulları sağlayan prosesler timeout ile sonlandırılır.
 *
 * Not: Yalnızca yorum satırları eklenmiştir; çalışma mantığı/değişkenler korunmuştur.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scheduler.h"
#include "queue.h"

/* Dosyadan okunan tüm görevler burada tutulur. */
TaskData gorevler[50];
int gorevSayisi = 0;

/* Simülasyonun global saniye sayacı. */
int globalTime = 0;

/* Kuyruklar: queues[p] -> p öncelik seviyesindeki TaskData* listesini tutar. */
TaskData* queues[MAX_QUEUE_LEVEL][50];
/* Her öncelik seviyesindeki eleman sayısı. */
int queue_lens[MAX_QUEUE_LEVEL] = {0};

/* Basit kuyruk ekleme (FIFO).
 * p seviye sınırı aşarsa en alt seviyeye sıkıştırılır. */
void Enqueue(int p, TaskData* t) {
    if (p >= MAX_QUEUE_LEVEL) p = MAX_QUEUE_LEVEL - 1;
    queues[p][queue_lens[p]] = t;
    queue_lens[p]++;
}

/* Basit kuyruk çıkarma (FIFO) - ilk elemanı döndürür ve diziyi sola kaydırır. */
TaskData* Dequeue(int p) {
    if (queue_lens[p] == 0) return NULL;
    TaskData* t = queues[p][0];
    for (int i = 0; i < queue_lens[p] - 1; i++) {
        queues[p][i] = queues[p][i+1];
    }
    queue_lens[p]--;
    return t;
}

/* Belirli bir görevi (adres eşitliğiyle) kuyruktan siler.
 * Timeout gibi durumlarda kullanılan yardımcı fonksiyon. */
void RemoveTaskFromQueue(int p, TaskData* t) {
    int foundIndex = -1;
    for (int i = 0; i < queue_lens[p]; i++) {
        if (queues[p][i] == t) {
            foundIndex = i;
            break;
        }
    }
    if (foundIndex != -1) {
        for (int i = foundIndex; i < queue_lens[p] - 1; i++) {
            queues[p][i] = queues[p][i+1];
        }
        queue_lens[p]--;
    }
}

/* Girdi dosyasını okuyup her satırı "arrival, prio, burst" formatında parse eder.
 * Her proses için id otomatik atanır; remainingTime = burst olarak başlatılır. */
void DosyaOku(const char* dosyaAdi) {
    FILE *file = fopen(dosyaAdi, "r");
    if (file == NULL) { printf("HATA: Dosya yok!\n"); exit(1); }
    char line[100];
    int idCounter = 0;
    while (fgets(line, sizeof(line), file)) {
        int arrival, prio, burst;
        if (sscanf(line, "%d, %d, %d", &arrival, &prio, &burst) == 3) {
            sprintf(gorevler[gorevSayisi].id, "%04d", idCounter++);
            gorevler[gorevSayisi].arrivalTime = arrival;
            gorevler[gorevSayisi].priority = prio;
            gorevler[gorevSayisi].burstTime = burst;
            gorevler[gorevSayisi].remainingTime = burst;
            gorevler[gorevSayisi].hasStarted = 0;
            gorevler[gorevSayisi].startTime = -1;
            gorevler[gorevSayisi].isRunning = 0;
            gorevSayisi++;
        }
    }
    fclose(file);
}

/* FreeRTOS görevi: simülasyonun ana döngüsüdür.
 * Her iterasyon ~1 saniyeyi temsil eder (vTaskDelay(pdMS_TO_TICKS(1000))). */
void SimulationTask(void *pvParameters) {
    (void) pvParameters;
    printf("Simulasyon Basliyor...\n");

    TaskData* currentTask = NULL;   /* Bu tick'te CPU'yu alan görev */
    TaskData* previousTask = NULL;  /* Bir önceki tick'te çalışan görev */

    for(;;) {

        /* 1) Bu saniyede sisteme gelen prosesleri uygun kuyruğa ekle. */
        for(int i=0; i<gorevSayisi; i++) {
            if (gorevler[i].arrivalTime == globalTime) {
                gorevler[i].startTime = globalTime;
                Enqueue(gorevler[i].priority, &gorevler[i]);
            }
        }

        /* 2) Çalışacak görevi seç.
         * Öncelik 0 seviyesinde kalan süre > 0 ise mevcut görevi koru (bu kod bloğu
         * özellikle boş bırakılmış; "preempt etme" kararını burada veriyorsunuz).
         * Diğer durumlarda en üst öncelikli dolu kuyruğun başındaki eleman seçilir. */
        if (currentTask != NULL && currentTask->priority == 0 && currentTask->remainingTime > 0) {

        } else {
            currentTask = NULL;
            for(int p=0; p < MAX_QUEUE_LEVEL; p++) {
                if (queue_lens[p] > 0) {
                    currentTask = queues[p][0];
                    break;
                }
            }
        }

        /* 3) Seçilen görevi 1 saniye çalıştır: çıktı üret, remainingTime azalt. */
        if (currentTask != NULL && currentTask->remainingTime > 0) {
            if (currentTask->hasStarted == 0) {
                /* Görev ilk kez CPU aldı. */
                printf(BLUE "%-2d.0000 sn %-20s (id:%-4s  öncelik:%2d  kalan süre:%2d sn)\n" RESET,
                       globalTime, "proses başladı",
                       currentTask->id, currentTask->priority, currentTask->remainingTime);
                currentTask->hasStarted = 1;
                currentTask->isRunning = 1;
            }
            else if (currentTask != previousTask) {
                /* Önceki tick'ten farklı bir göreve geçildiyse "başladı" mesajı bas. */
                printf(BLUE "%-2d.0000 sn %-20s (id:%-4s  öncelik:%2d  kalan süre:%2d sn)\n" RESET,
                       globalTime, "proses başladı",
                       currentTask->id, currentTask->priority, currentTask->remainingTime);
                currentTask->isRunning = 1;
            }
            else {
                /* Aynı görev çalışmaya devam ediyorsa "yürütülüyor" mesajı bas. */
                printf(GREEN "%-2d.0000 sn %-20s (id:%-4s  öncelik:%2d  kalan süre:%2d sn)\n" RESET,
                       globalTime, "proses yürütülüyor",
                       currentTask->id, currentTask->priority, currentTask->remainingTime);
            }

            /* 1 saniyelik CPU kullanımını temsil eder. */
            currentTask->remainingTime--;
            previousTask = currentTask;
        }

        /* 4) Zamanı 1 saniye ilerlet. */
        vTaskDelay(pdMS_TO_TICKS(1000));
        globalTime++;

        /* 5) Quantum sonu işlemleri:
         *    - Biten proses: kuyruktan çıkar, sonlandı mesajı bas.
         *    - Bitmeyen ve priority > 0 olan proses: kuyruktan çıkar, bir alt önceliğe düşür,
         *      "askıda" mesajı bas, tekrar kuyruğa ekle. */
        if (currentTask != NULL) {
            if (currentTask->remainingTime == 0) {
                printf(MAGENTA "%-2d.0000 sn %-20s (id:%-4s  öncelik:%2d  kalan süre: 0 sn)\n" RESET,
                       globalTime, "proses sonlandı",
                       currentTask->id, currentTask->priority);

                Dequeue(currentTask->priority);
                currentTask->isRunning = 0;
                currentTask = NULL;
                previousTask = NULL;
            }
            else if (currentTask->priority > 0) {
                /* Seçilen proses kuyruk başındaydı; quantum sonunda kuyruktan çıkarıyoruz. */
                Dequeue(currentTask->priority);

                /* Önceliği (kuyruk seviyesini) bir derece düşür (MAX_QUEUE_LEVEL-1'e kadar). */
                if (currentTask->priority < MAX_QUEUE_LEVEL - 1) {
                    currentTask->priority++;
                }

                printf(YELLOW "%-2d.0000 sn %-20s (id:%-4s  öncelik:%2d  kalan süre:%2d sn)\n" RESET,
                       globalTime, "proses askıda",
                       currentTask->id, currentTask->priority, currentTask->remainingTime);

                Enqueue(currentTask->priority, currentTask);
                currentTask->isRunning = 0;
                currentTask = NULL;
            }
        }

        /* 6) Tüm prosesler bittiyse simülasyonu sonlandır. */
        int aktif = 0;
        for(int i=0; i<gorevSayisi; i++)
            if (gorevler[i].remainingTime > 0) aktif = 1;

        if (!aktif && globalTime > 5) {
            exit(0);
        }

        /* 7) Timeout kontrolü:
         * startTime'dan itibaren 20 saniyeyi geçen ve belirli kurallara uyan prosesler
         * "zamanaşımı" ile sonlandırılır ve kuyruktan çıkarılır. */
        for(int i=0; i<gorevSayisi; i++) {
            if (gorevler[i].startTime != -1 && gorevler[i].remainingTime > 0) {
                int timePassed = globalTime - gorevler[i].startTime;
                if (timePassed >= 20) {
                    int kill = 0;
                    if (gorevler[i].hasStarted == 0) kill = 1;
                    else if (gorevler[i].priority < 3) kill = 1;

                    if (kill) {
                        printf(RED "%-2d.0000 sn %-20s (id:%-4s  öncelik:%2d  kalan süre:%2d sn)\n" RESET,
                               globalTime, "proses zamanaşımı",
                               gorevler[i].id, gorevler[i].priority, gorevler[i].remainingTime);

                        RemoveTaskFromQueue(gorevler[i].priority, &gorevler[i]);
                        gorevler[i].remainingTime = 0;
                        if (currentTask == &gorevler[i]) currentTask = NULL;
                    }
                }
            }
        }
    }
}
