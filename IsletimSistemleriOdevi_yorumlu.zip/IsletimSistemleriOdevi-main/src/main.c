/*
 * main.c
 * -------
 * FreeRTOS POSIX port üzerinde çalışan örnek bir zamanlayıcı (scheduler) simülasyonunun
 * giriş noktasıdır.
 *
 * Bu dosyada:
 *  - FreeRTOS configASSERT tetiklendiğinde çağrılan vAssertCalled fonksiyonu
 *  - Girdi dosyasını okuyup (giris.txt veya argv[1]) görevleri yükleme
 *  - Simülasyon görevini (SimulationTask) oluşturup FreeRTOS scheduler'ını başlatma
 *
 * Not: Yalnızca yorum satırları eklenmiştir; çalışma mantığı/değişkenler korunmuştur.
 */

#include <stdio.h>
#include <stdlib.h>
#include "FreeRTOS.h"
#include "task.h"
#include "scheduler.h"

/* configASSERT başarısız olduğunda (FreeRTOSConfig.h içinden) buraya düşer.
 * Hata konumunu yazdırıp programı sonlandırır. */
void vAssertCalled(const char *pcFile, unsigned long ulLine) {
    printf("ASSERTION FAILED! File: %s, Line: %lu\n", pcFile, ulLine);
    exit(-1);
}

int main(int argc, char *argv[]) {

    /* Komut satırından dosya adı verilmişse onu kullan, yoksa varsayılan giris.txt. */
    const char* filename = (argc > 1) ? argv[1] : "giris.txt";
    DosyaOku(filename);

    /* Simülasyonu yürüten FreeRTOS görevini en yüksek önceliklerden biriyle oluştur. */
    xTaskCreate(SimulationTask, "Scheduler", 4096, NULL, configMAX_PRIORITIES-1, NULL);

    /* FreeRTOS scheduler'ını başlat: bundan sonra kontrol tick'ler ve görevlerdedir. */
    vTaskStartScheduler();

    /* Normal şartlarda buraya dönülmez (heap yetersizliği vb. durumlar hariç). */
    return 0;
}
