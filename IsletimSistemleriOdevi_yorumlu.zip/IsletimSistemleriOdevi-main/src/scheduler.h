/*
 * scheduler.h
 * -----------
 * Simülasyonda kullanılan görev (process) veri yapıları ve zamanlayıcı arayüzü.
 *
 * Proje mantığı: Dosyadan gelen süreçleri (arrivalTime, priority, burstTime)
 * çok seviyeli kuyruk (MAX_QUEUE_LEVEL) yapısına alıp her saniye yürütme/demote etme.
 *
 * Not: Yalnızca yorum satırları eklenmiştir; çalışma mantığı/değişkenler korunmuştur.
 */

#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "FreeRTOS.h"
#include "task.h"

/* Terminal çıktısını renklendirmek için ANSI escape kodları. */
#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define MAGENTA "\033[35m"

/* Çok seviyeli kuyruk sayısı (0: en yüksek öncelik, daha büyük: daha düşük). */
#define MAX_QUEUE_LEVEL 4

/* Her bir proses/görev için tutulan bilgiler. */
typedef struct {
    char id[16];          /* Görev kimliği (dosyadan okunurken otomatik atanır) */
    int arrivalTime;      /* Sisteme giriş zamanı (sn) */
    int priority;         /* Kuyruk seviyesi/öncelik (0 en yüksek) */
    int burstTime;        /* Toplam çalışma süresi (sn) */
    int remainingTime;    /* Kalan çalışma süresi (sn) */

    int startTime;        /* Sisteme alındığı/aktif hale geldiği zaman (sn) */
    int hasStarted;       /* İlk kez CPU aldı mı? (0/1) */
    int isRunning;        /* O an CPU üzerinde mi? (0/1) */
} TaskData;

/* Simülasyonda kullanılan global veri dizileri/değişkenler. */
extern TaskData gorevler[50];
extern int gorevSayisi;
extern int globalTime;

/* FreeRTOS görevi: her tick'te (1 sn) zamanlayıcı simülasyonunu yürütür. */
void SimulationTask(void *pvParameters);

/* Girdi dosyasından prosesleri okuyup gorevler[] dizisine yükler. */
void DosyaOku(const char* dosyaAdi);

#endif
