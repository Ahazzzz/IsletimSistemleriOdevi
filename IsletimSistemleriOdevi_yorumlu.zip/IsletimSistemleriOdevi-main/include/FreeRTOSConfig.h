/*
 * FreeRTOSConfig.h
 * ----------------
 * FreeRTOS POSIX port için proje bazlı konfigürasyon ayarları.
 *
 * Bu dosya, FreeRTOS çekirdeğinin hangi özelliklerle derleneceğini belirler
 * (tick hızı, öncelik sayısı, heap büyüklüğü, timer ayarları vb.).
 *
 * Not: Yalnızca yorum satırları eklenmiştir; macro değerleri korunmuştur.
 */

#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

#include <stdio.h>
#include <stdlib.h>

/* Scheduler davranışı ve temel özellikler */
#define configUSE_PREEMPTION                    1
#define configUSE_PORT_OPTIMISED_TASK_SELECTION 0
#define configUSE_IDLE_HOOK                     0
#define configUSE_TICK_HOOK                     0

/* Tick frekansı: burada 1000 Hz => 1 ms tick */
#define configTICK_RATE_HZ                      ( ( TickType_t ) 1000 )

/* Öncelik ve bellek ayarları */
#define configMAX_PRIORITIES                    ( 5 )
#define configMINIMAL_STACK_SIZE                ( ( unsigned short ) 70 )
#define configTOTAL_HEAP_SIZE                   ( ( size_t ) ( 65 * 1024 ) )
#define configMAX_TASK_NAME_LEN                 ( 16 )

/* Çeşitli çekirdek seçenekleri */
#define configUSE_TRACE_FACILITY                0
#define configUSE_16_BIT_TICKS                  0
#define configIDLE_SHOULD_YIELD                 1
#define configUSE_MUTEXES                       1
#define configQUEUE_REGISTRY_SIZE               8
#define configCHECK_FOR_STACK_OVERFLOW          0
#define configUSE_RECURSIVE_MUTEXES             1
#define configUSE_MALLOC_FAILED_HOOK            0
#define configUSE_APPLICATION_TASK_TAG          0
#define configUSE_COUNTING_SEMAPHORES           1

/* Yazılım timer ayarları */
#define configUSE_TIMERS                        1
#define configTIMER_TASK_PRIORITY               ( configMAX_PRIORITIES - 1 )
#define configTIMER_QUEUE_LENGTH                5
#define configTIMER_TASK_STACK_DEPTH            ( configMINIMAL_STACK_SIZE * 2 )

/* API fonksiyonlarının derlemeye dahil edilip edilmeyeceği */
#define INCLUDE_vTaskPrioritySet                1
#define INCLUDE_uxTaskPriorityGet               1
#define INCLUDE_vTaskDelete                     1
#define INCLUDE_vTaskCleanUpResources           0
#define INCLUDE_vTaskSuspend                    1
#define INCLUDE_vTaskDelayUntil                 1
#define INCLUDE_vTaskDelay                      1

/* Assert altyapısı: configASSERT(x) başarısız olursa vAssertCalled çağrılır. */
extern void vAssertCalled( const char *pcFile, unsigned long ulLine );
#define configASSERT( x ) if( ( x ) == 0 ) vAssertCalled( __FILE__, __LINE__ )

#endif
